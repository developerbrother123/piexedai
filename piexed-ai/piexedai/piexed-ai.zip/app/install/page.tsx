import InstallerPage from "@/install/index"

export default function Page() {
  return <InstallerPage />
}

